# CC91 论坛系统 — 验收操作指南

> 适用场景：项目答辩 / 课程验收 / 交付评审
> 预计时长：60–90 分钟（含 Q&A）
> 前置准备：按 `docs/env-setup.md` 启动全部服务

---

## 零、验收前准备（现场或提前完成）

### 0.1 环境启动

> 推荐 Docker 一键启动（9 个容器：MySQL + Eureka + Gateway + 6 业务服务 + Prometheus + Grafana + 前端 Nginx）。

```bash
# 推荐：Docker Compose 一键启动
cp .env.example .env       # 配置 DB_PASSWORD / JWT_SECRET 等
docker compose up -d --build
docker compose ps          # 等待所有容器 healthy（约 1-2 分钟）
```

如需本地无 Docker 启动（IDE 调试场景），参考 [`env-setup.md`](env-setup.md)。

验证清单（全部打勾后再进入正式验收）：

- [ ] Eureka 控制台 http://localhost:8761 可访问，**7 个服务已注册**（Gateway + User + Forum + Notification + Content + File + 自身）
- [ ] Gateway http://localhost:9000 可访问
- [ ] 前端 http://localhost:3001 可访问（Docker 模式）；本地 Vite 模式为 5173
- [ ] MySQL 数据库连接正常，`cc91_db` 存在且有数据
- [ ] Prometheus http://localhost:19090 可访问（指标采集）
- [ ] Grafana http://localhost:3000 可访问（监控仪表盘）

### 0.2 准备演示数据

确保数据库中已有：
- 至少 2 个分类
- 至少 5 篇帖子（含草稿）
- 至少 1 篇公告（含置顶）
- 至少 2 个用户（1 普通用户 + 1 管理员）
- 至少 3 条评论

---

## 一、功能验收（25 分钟）

### 1.1 用户认证流程（5 分钟）

**展示目标**：注册 → 邮箱验证 → 登录 → Token 管理

| 步骤 | 操作 | 预期结果 | 亮点说明 |
|------|------|----------|----------|
| 1 | 点击「注册」，填写用户名/邮箱/密码 | 注册成功，提示验证邮箱 | 后端发送验证码（控制台可见） |
| 2 | 输入邮箱收到的 6 位验证码 | 验证通过，账号激活 | 验证码 10 分钟过期，一次性使用 |
| 3 | 使用新账号登录 | 登录成功，跳转首页，Header 显示用户名 | JWT 无状态认证，Access Token 1h 过期 |
| 4 | 等待或手动模拟 Token 过期 | 自动使用 Refresh Token 续期，用户无感知 | 双 Token 机制（Access + Refresh） |
| 5 | 点击「退出」 | 退出成功，Refresh Token 被撤销 | 后端 revoke 策略，无法重放 |

**演示技巧**：
- 打开浏览器 DevTools → Network 标签，展示 `/api/auth/login` 返回的 JWT Token
- 打开 https://jwt.io 粘贴 Token，展示 payload 中的 `sub`、`userId`、`role` 字段
- 展示后端控制台输出的验证码日志

### 1.2 帖子全生命周期（5 分钟）

**展示目标**：发帖 → 编辑 → 浏览 → 搜索 → 删除

| 步骤 | 操作 | 预期结果 | 亮点说明 |
|------|------|----------|----------|
| 1 | 点击「发帖」，选择分类，填写标题和富文本内容 | 帖子创建成功，支持保存为草稿 | 草稿/发布双状态 |
| 2 | 在「我的草稿」中打开草稿，点击发布 | 草稿变为已发布 | 状态流转 |
| 3 | 在帖子列表浏览帖子，点击进入详情 | 显示帖子内容、作者信息、浏览量 +1 | 浏览量计数（乐观锁防并发） |
| 4 | 使用顶部搜索框搜索帖子标题关键词 | 返回匹配结果 | 全文搜索 |
| 5 | 点击「编辑」修改帖子内容 | 更新成功 | 权限校验：仅作者可编辑 |
| 6 | 点击「删除」 | 帖子消失 | 权限校验：仅作者或管理员可删除 |

### 1.3 互动功能（5 分钟）

**展示目标**：评论 → 回复 → 点赞 → 收藏 → 举报

| 步骤 | 操作 | 预期结果 | 亮点说明 |
|------|------|----------|----------|
| 1 | 在帖子详情页发表评论 | 评论出现在列表中 | 实时刷新 |
| 2 | 点击某条评论的「回复」 | 回复嵌套在父评论下方 | 多级嵌套评论树 |
| 3 | 点击帖子「点赞」按钮 | 点赞数 +1，按钮高亮；再点取消 | 前端即时反馈，后端 toggle 逻辑 |
| 4 | 点击帖子「收藏」按钮 | 收藏成功 | 「我的收藏」页面可见 |
| 5 | 点击「举报」，选择原因提交 | 举报记录创建成功 | 举报进入管理员审核队列 |

**演示技巧**：
- 展示评论的树形结构：一级评论 → 回复
- 在 Network 面板展示 `POST /api/posts/{id}/like` 的 toggle 行为（同一接口，点赞/取消）

### 1.4 个人中心（3 分钟）

**展示目标**：个人主页 → 资料编辑 → 头像上传 → 密码修改

| 步骤 | 操作 | 预期结果 |
|------|------|----------|
| 1 | 点击用户名进入个人主页 | 显示头像、简介、发帖数等 |
| 2 | 点击「编辑资料」修改签名、所在地等 | 保存成功，个人页即时更新 |
| 3 | 上传新头像 | 头像更新（File Service 独立处理） |
| 4 | 进入「修改密码」页，输入旧密码和新密码 | 修改成功，需重新登录 |

### 1.5 通知系统（2 分钟）

| 步骤 | 操作 | 预期结果 |
|------|------|----------|
| 1 | 用 A 账号评论 B 的帖子 | B 的通知铃铛显示未读数 +1 |
| 2 | B 点击通知铃铏 | 展示通知列表，可标记已读 |
| 3 | B 点击「全部已读」 | 所有通知标记为已读，未读数清零 |

### 1.6 管理后台（5 分钟）

**展示目标**：管理员专属功能的完整闭环

切换到管理员账号登录，访问 `/admin`：

| 步骤 | 操作 | 预期结果 | 亮点说明 |
|------|------|----------|----------|
| 1 | 查看管理仪表盘 | 显示用户数、帖子数、评论数等统计 | 聚合多服务数据 |
| 2 | 用户管理：查看用户列表，封禁某用户 | 该用户无法登录 | 账号锁定 + 状态展示 |
| 3 | 分类管理：新增/编辑/删除分类 | 分类更新，前端同步刷新 | 分类排序支持 |
| 4 | 内容审核：查看举报列表，处理举报 | 状态变为「已处理」，可下架帖子 | 完整举报 → 审核闭环 |
| 5 | 公告管理：发布公告，设置置顶 | 公告出现在首页顶部 | 置顶排序 |

**演示技巧**：
- 展示普通用户访问 `/admin` 路径会被 `AdminRoute` 拦截并重定向
- 在 Network 面板展示管理员 API 的 `Authorization` header 中 JWT 包含 `role: ADMIN`

---

## 二、非功能验收 — 安全性（10 分钟）

### 2.1 安全架构说明（口头 + 截图）

展示要点（可提前准备 PPT/截图）：

| 安全措施 | 对应 OWASP 类别 | 如何展示 |
|----------|-----------------|----------|
| JWT 无状态认证 | A07 | 展示 Token payload、刷新/撤销机制 |
| RBAC 权限控制 | A01 | 普通用户访问 admin API 返回 403 |
| 账户锁定（连续失败触发，阈值由后端配置控制） | A07 | 连续输错密码演示锁定效果 |
| bcrypt 密码哈希 | A02 | 展示数据库中密码是哈希值而非明文 |
| HTML 消毒（DOMPurify + 后端 HtmlSanitizer） | A03 | 发帖内容插入 `<script>alert('xss')</script>` 被过滤 |
| CORS 白名单 | A05 | 展示 SecurityConfig 中 CORS 配置 |
| 环境变量管理密钥 | A05 | 展示无硬编码密钥，JWT_SECRET 必须配置 |
| 服务间内部认证 | A01 | 展示 `InternalApiAuthFilter` |

### 2.2 XSS 防护实战演示

```
1. 打开发帖页面
2. 标题输入: 正常标题
3. 内容输入: <script>alert('XSS攻击')</script><img src=x onerror=alert('XSS')>
4. 点击发布
5. 查看帖子详情页 — 脚本标签被过滤，不执行
6. 展示后端数据库中存储的也是消毒后的内容
```

### 2.3 权限控制演示

```
1. 用普通用户 Token 调用管理员 API:
   curl -H "Authorization: Bearer <普通用户Token>" http://localhost:9000/api/admin/users
2. 返回 403 Forbidden
3. 展示 SecurityConfig 中 hasRole('ADMIN') 配置
```

### 2.4 账户锁定演示

```
1. 连续 5 次用错误密码登录同一账号
2. 第 6 次返回 "账户已锁定"
3. 展示后端日志中的锁定记录
```

### 2.5 安全审查报告

展示 `docs/security-audit.md`，说明已按 OWASP Top 10 全覆盖审查。

---

## 三、非功能验收 — 压力测试（10 分钟）

### 3.1 运行压力测试

> **现场演示推荐配置**：30 并发 / 每场景 10 秒，总耗时约 85 秒，8 场景全部 100% 成功。
>
> 完整基线（50 并发 / 15 秒）见 `docs/stress-test/stress-test-report.md`。

```bash
# 现场演示参数（推荐）
python docs/stress-test/stress_test.py \
  --base-url http://localhost:9000 \
  --concurrency 30 --duration 10 \
  --output docs/stress-test/stress_test_result.json

# 完整基线参数（演示前预跑用，耗时约 2.5 分钟）
python docs/stress-test/stress_test.py \
  --base-url http://localhost:9000 \
  --concurrency 50 --duration 15 \
  --output docs/stress-test/stress_test_result.json
```

### 3.2 展示已有测试报告

打开 `docs/stress-test/stress-test-report.md`，讲解 8 个场景的结果：

| 场景 | 关注指标 | 说明要点 |
|------|----------|----------|
| 只读基准 | RPS, P99 | 公开接口无认证开销，展示吞吐基线 |
| 单接口极限 - /categories | 独立 RPS | 字典类接口性能 |
| 单接口极限 - /posts | 独立 RPS | 万级数据下分页查询性能 |
| 单接口极限 - /announcements | 独立 RPS | 通常吞吐最高（数据量小） |
| 认证压力 | 登录 RPS | BCrypt 是 CPU 密集操作，展示认证瓶颈 |
| 读写混合（80/20） | 稳定性 | 模拟真实使用场景 |
| 并发写入 | 成功率 | 展示数据一致性保证 |
| 帖子详情+评论 | 延迟 | 复杂查询性能 |

### 3.3 讲解要点

- 使用 Python 标准库（无第三方依赖），展示工程简洁性
- 结果输出包含 RPS、平均延迟、P50/P90/P95/P99、状态码分布
- **30 并发演示配置**：所有场景 100% 成功，P99 < 2.2s（登录因 BCrypt 计算密集是最慢场景）
- **50 并发完整基线**：暴露尾延迟尖刺（少数请求达 30s 超时），说明系统容量边界

---

## 四、架构与部署（10 分钟）

### 4.1 微服务架构图（口头讲解）

展示或绘制以下架构：

```
                         ┌──────────┐
                         │  前端 SPA │  :3001 (Docker) / :5173 (Vite)
                         └─────┬────┘
                               │
                         ┌─────▼────┐
                         │  Gateway  │  :9000
                         └─────┬────┘
                               │
                    ┌──────────┼──────────┐
                    │          │          │
              ┌─────▼──┐ ┌────▼───┐ ┌───▼────┐
              │  User  │ │ Forum  │ │Content │  ...
              │Service │ │Service │ │Service │
              └────────┘ └────────┘ └────────┘
                    │          │          │
                    └──────────┼──────────┘
                               │
                         ┌─────▼────┐
                         │  MySQL   │
                         └──────────┘
                    ┌──────────┐
                    │  Eureka  │  :8761
                    │  Server  │
                    └──────────┘
```

### 4.2 服务治理演示

| 展示内容 | 操作 |
|----------|------|
| 服务注册发现 | 打开 http://localhost:8761，展示 7 个已注册实例（Gateway + 6 业务服务） |
| Gateway 路由 | 展示 Gateway 配置文件中的路由规则 |
| 服务间调用 | 讲解 Feign Client 的使用（如 Forum Service 调用 User Service 获取作者信息） |
| 健康检查 | 访问 `http://localhost:8081/actuator/health` 展示健康状态 |

### 4.3 数据库设计

展示 Flyway 迁移文件，说明：

- 每个服务独立数据库 schema（或独立表空间）
- 迁移脚本版本化管理
- 关键表：users, posts, comments, categories, notifications, announcements, reports

### 4.4 部署方式

说明当前部署方案（详见 [`docker-deployment-guide.md`](docker-deployment-guide.md)）：

- **推荐：Docker Compose 一键启动 9 个容器**
  - `docker compose up -d --build` 启动全部服务
  - 多阶段构建镜像，最终镜像基于轻量 JRE/Alpine
  - healthcheck 保证启动顺序（MySQL/Eureka 就绪后才启动下游）
  - 容器自动重启（`restart: unless-stopped`）
- **本地无 Docker 启动**（IDE 调试场景）：`start-microservices.bat` + `start-frontend.bat`，参考 [`env-setup.md`](env-setup.md)
- **服务治理**：Eureka 实现服务发现，Gateway 统一入口，OpenFeign 服务间调用

---

## 五、开发过程与协作（10 分钟）

### 5.1 Git 工作流

| 展示内容 | 操作 |
|----------|------|
| 分支策略 | `git branch -a` 展示 main / develop / feat/* 分支体系 |
| 提交规范 | `git log --oneline -20` 展示 conventional commits |
| PR 合并记录 | `gh pr list --state merged` 或在 GitHub 展示已合并 PR |
| 代码审查 | 展示 PR 中的 review 评论 |

**命令速查**：

```bash
# 展示分支
git branch -a

# 展示提交历史
git log --oneline --graph --all -30

# 展示贡献者
git shortlog -sn --all

# 展示合并的 PR
gh pr list --state merged --limit 10
```

### 5.2 团队协作数据

| 指标 | 数据 | 说明 |
|------|------|------|
| 总提交数 | 156（当前分支） / 198（全分支） | `git log --oneline \| wc -l` |
| 贡献者数 | 11 人 | `git shortlog -sn --all` |
| 功能分支数 | 10+ 个 feat/ 分支 | 展示功能拆分粒度 |
| PR 合并数 | 5+ 个已合并 PR | `gh pr list --state merged` |

### 5.3 文档体系

展示 `docs/` 目录下的完整文档：

| 文档 | 内容 |
|------|------|
| `project-summary.md` / `report.pdf` | 项目总结（21 页 PDF 主报告） |
| `microservices-design.md` | 微服务拆分设计 v2.0 |
| `api-reference.md` | API 接口文档 |
| `security-audit.md` | 安全审查报告 |
| `stress-test/stress-test-report.md` | 压力测试报告 |
| `env-setup.md` | 环境搭建指南 |
| `docker-deployment-guide.md` | Docker 一键部署 |
| `issues.md` | 问题跟踪 |

### 5.4 测试覆盖

| 层级 | 覆盖范围 | 如何展示 |
|------|----------|----------|
| 前端单元测试 | 46 个测试文件 | `cd frontend && npx vitest run` |
| 后端单元测试 | Controller/Service/Repository 层 | `cd microservices && mvn test` |
| 压力测试 | 8 场景 | `python docs/stress-test/stress_test.py` |
| 安全审查 | OWASP Top 10 | 展示 `security-audit.md` |

---

## 六、验收收尾（5 分钟）

### 6.1 总结陈述模板

> CC91 论坛系统是一个基于 **Spring Boot 微服务架构**的校园论坛平台，包含 6 个业务微服务 + API 网关 + 服务注册中心，并通过 Docker Compose 实现一键部署。
>
> **功能方面**：实现了用户认证、帖子管理、评论互动、通知系统、管理后台等完整的论坛功能闭环。
>
> **安全方面**：按照 OWASP Top 10 标准进行了全面安全审查，包含 JWT 认证、RBAC 权限、XSS 双层防护、账户锁定等。
>
> **性能方面**：30 并发 / 10 秒演示压测下，8 个场景全部 100% 成功，P99 < 2.2s；50 并发完整基线见压测报告。
>
> **工程方面**：团队 11 人协作，156 次提交，conventional commits 规范，PR 审查流程，完整文档体系。

### 6.2 可能的提问与应对

| 可能的提问 | 建议回答要点 |
|------------|-------------|
| 为什么选择微服务架构？ | 独立部署/扩展、技术异构性、故障隔离、团队分工 |
| 微服务间如何通信？ | Feign 声明式 HTTP 客户端 + Eureka 服务发现 |
| 如何保证数据一致性？ | 每个服务独立数据源，通过 API 保证最终一致性 |
| 性能瓶颈在哪？ | 登录接口（BCrypt 密码校验是 CPU 密集型，30 并发下 P99 约 2s）+ 帖子列表分页查询（万级数据下偶发尾延迟）。优化方向：Redis 缓存 Token / 复合索引 / 异步化浏览量更新 |
| 安全方面最关键的措施？ | JWT 无状态认证 + RBAC + XSS 双层防护（DOMPurify + HtmlSanitizer）+ 环境变量管理密钥 |
| 如果用户量增长 10 倍怎么办？ | Gateway 层负载均衡、数据库读写分离、缓存热点数据、按服务独立扩容 |
| 为什么选择 Docker 部署？ | 一键启动 9 个容器、环境隔离、healthcheck 保证启动顺序、版本可移植、易于扩缩容 |
| 微服务间如何保证一致性？ | 当前共享数据库（DB-per-Service 过渡形态），通过 API 保证最终一致性；未来可引入 Saga |
| 测试策略是什么？ | 分层测试：单元测试覆盖核心逻辑（JUnit 5 + Vitest），集成测试覆盖 API，压力测试验证性能，安全审查覆盖 OWASP 攻击面 |

---

## 附录：验收当天 Checklist

```
环境准备
  [ ] MySQL 运行中，cc91_db 有数据
  [ ] 全部 9 个容器启动成功（docker compose ps 全 healthy）
  [ ] Eureka 控制台显示 7 个注册实例（Gateway + 6 业务服务）
  [ ] 前端可正常访问（http://localhost:3001 Docker 或 5173 Vite）

功能演示
  [ ] 注册 + 邮箱验证
  [ ] 登录 + JWT Token 展示
  [ ] 发帖 + 编辑 + 删除
  [ ] 评论 + 回复
  [ ] 点赞 + 收藏
  [ ] 搜索
  [ ] 个人资料 + 头像上传
  [ ] 通知铃铛
  [ ] 管理后台（用户管理 + 内容审核 + 公告）

安全演示
  [ ] XSS 防护（脚本注入被过滤）
  [ ] 权限控制（普通用户 403）
  [ ] 账户锁定（连续错误密码）

性能演示
  [ ] 压力测试脚本运行
  [ ] 结果报告展示

架构展示
  [ ] Eureka 控制台截图
  [ ] 架构图讲解
  [ ] Gateway 路由配置

协作展示
  [ ] Git 提交历史
  [ ] 分支策略
  [ ] 贡献者统计
  [ ] 文档目录

文档展示
  [ ] docs/ 目录结构
  [ ] 安全审查报告
  [ ] 压力测试报告
  [ ] API 文档
```
